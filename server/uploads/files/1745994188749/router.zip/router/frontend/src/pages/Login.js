import Login from '../components/LoginForm'

function LoginPage(){
    return <div><Login/></div>
}

export default LoginPage;