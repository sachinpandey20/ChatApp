import classes from './LoginForm.module.css';


function Login(){
    return (
        <div className = {classes.container}>
            <form className={classes.formContainer}>
                <p className={classes.inputContainer}>
                    <h2>Please Login</h2>
                </p> 
                <div className={classes.fieldsContainer}>
                    <p className={classes.inputContainer}>
                        <label>Enter email</label>
                        <input type='email' className={classes.inputField}/>
                    </p>
                    <p className={classes.inputContainer} >
                        <label>Enter password</label>
                        <input type='password'/>
                    </p>
                </div>
                <div>
                    <button>Login</button>
                    <p>
                        <span>New User?</span>
                        <button>Sign up</button>
                    </p>
                </div>
            </form>
        </div>
    )
}

export default Login